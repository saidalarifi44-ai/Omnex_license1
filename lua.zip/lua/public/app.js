// Check auth
if (!localStorage.getItem('admin_token')) {
    window.location.href = '/index.html';
}

function logout() {
    localStorage.removeItem('admin_token');
    window.location.href = '/index.html';
}

async function fetchAPI(endpoint, options = {}) {
    const res = await fetch(endpoint, options);
    return res.json();
}

async function loadStats() {
    const stats = await fetchAPI('/api/admin/stats');
    document.getElementById('totalLicenses').textContent = stats.total_licenses;
    document.getElementById('activeLicenses').textContent = stats.active_licenses;
    document.getElementById('totalLogs').textContent = stats.total_logs;
}

async function loadLicenses() {
    const licenses = await fetchAPI('/api/admin/licenses');
    const tbody = document.getElementById('licensesTable');

    if (licenses.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="p-8 text-center text-slate-500">No licenses found. Create one to get started.</td></tr>`;
        return;
    }

    tbody.innerHTML = licenses.map(l => {
        const expires = l.expires_at ? moment(l.expires_at).format('MMM D, YYYY') : '<span class="text-slate-600">Lifetime</span>';
        const isExpired = l.expires_at && new Date(l.expires_at) < new Date();

        let statusBadge;
        if (isExpired) {
            statusBadge = `<span class="px-2.5 py-1 rounded-full text-xs font-bold bg-red-500/10 text-red-400 border border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.2)]">EXPIRED</span>`;
        } else if (l.status === 'active') {
            statusBadge = `<span class="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-[0_0_10px_rgba(16,185,129,0.2)]">ACTIVE</span>`;
        } else {
            statusBadge = `<span class="px-2.5 py-1 rounded-full text-xs font-bold bg-red-500/10 text-red-400 border border-red-500/20">BANNED</span>`;
        }

        return `
        <tr class="table-row-hover transition group border-b border-slate-800/50 last:border-0">
            <td class="p-5 pl-8 font-mono text-xs text-blue-400 font-medium tracking-wide">
                <div class="flex items-center gap-2">
                    <i data-lucide="key" class="w-3 h-3 opacity-50"></i>
                    ${l.key}
                </div>
                ${l.discord_id ? `<div class="mt-1 text-[10px] text-slate-500 flex items-center gap-1"><i data-lucide="message-square" class="w-2.5 h-2.5"></i> ${l.discord_id}</div>` : ''}
            </td>
            <td class="p-5 font-mono text-xs text-slate-400">${l.ip || '<span class="text-slate-600 italic">Unbound</span>'}</td>
            <td class="p-5">${statusBadge}</td>
            <td class="p-5 text-xs text-slate-400">${expires}</td>
            <td class="p-5 text-slate-500 text-xs">${moment(l.created_at).fromNow()}</td>
            <td class="p-5 text-right pr-8">
                <div class="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onclick="openEditModal(${l.id}, '${l.ip || ''}', '${l.expires_at || ''}', '${l.discord_id || ''}')" class="p-2 rounded-lg hover:bg-blue-500/20 text-blue-400 transition border border-transparent hover:border-blue-500/30" title="Edit">
                        <i data-lucide="edit-2" class="w-4 h-4"></i>
                    </button>
                    <button onclick="resetIP(${l.id})" class="p-2 rounded-lg hover:bg-yellow-500/20 text-yellow-400 transition border border-transparent hover:border-yellow-500/30" title="Reset IP">
                        <i data-lucide="refresh-ccw" class="w-4 h-4"></i>
                    </button>
                    <button onclick="toggleStatus(${l.id})" class="p-2 rounded-lg hover:bg-orange-500/20 ${l.status === 'active' ? 'text-orange-400' : 'text-emerald-400'} transition border border-transparent hover:border-orange-500/30" title="${l.status === 'active' ? 'Ban' : 'Unban'}">
                        <i data-lucide="${l.status === 'active' ? 'ban' : 'check-circle'}" class="w-4 h-4"></i>
                    </button>
                    <button onclick="deleteLicense(${l.id})" class="p-2 rounded-lg hover:bg-red-500/20 text-red-400 transition border border-transparent hover:border-red-500/30" title="Delete">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                </div>
            </td>
        </tr>
    `}).join('');

    lucide.createIcons();
}

async function loadLogs() {
    const logs = await fetchAPI('/api/admin/logs');
    const tbody = document.getElementById('logsTable');

    if (logs.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="p-8 text-center text-slate-500">No activity logs yet.</td></tr>`;
        return;
    }

    tbody.innerHTML = logs.map(l => `
        <tr class="table-row-hover transition border-b border-slate-800/50 last:border-0">
            <td class="p-5 pl-8 text-slate-500 whitespace-nowrap text-xs font-mono">${moment(l.timestamp).format('MMM D, HH:mm:ss')}</td>
            <td class="p-5 font-mono text-xs text-blue-400/80">${l.license_key}</td>
            <td class="p-5 font-mono text-xs text-slate-400">${l.ip}</td>
            <td class="p-5">
                <span class="${l.status === 'Success' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' : 'text-red-400 bg-red-500/10 border-red-500/20'} text-xs font-bold px-2 py-1 rounded-md border flex items-center gap-2 w-fit">
                    <i data-lucide="${l.status === 'Success' ? 'check' : 'x-circle'}" class="w-3 h-3"></i>
                    ${l.status}
                </span>
            </td>
        </tr>
    `).join('');

    lucide.createIcons();
}

async function createLicense() {
    if (!confirm("Create a new license?")) return;
    await fetchAPI('/api/admin/licenses', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) });
    refreshAll();
}

// Modal Functions
function openEditModal(id, ip, expires, discordId) {
    document.getElementById('editId').value = id;
    document.getElementById('editIp').value = ip;
    document.getElementById('editDiscordId').value = discordId !== 'null' && discordId !== 'undefined' ? discordId : '';

    // Format for datetime-local: YYYY-MM-DDTHH:mm
    if (expires && expires !== 'null' && expires !== 'undefined') {
        document.getElementById('editExpires').value = moment(expires).format('YYYY-MM-DDTHH:mm');
    } else {
        document.getElementById('editExpires').value = '';
    }
    document.getElementById('editModal').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('editModal').classList.add('hidden');
}

async function saveLicense() {
    const id = document.getElementById('editId').value;
    const ip = document.getElementById('editIp').value;
    const discord_id = document.getElementById('editDiscordId').value;
    const expires = document.getElementById('editExpires').value; // Returns YYYY-MM-DDTHH:mm or empty

    await fetchAPI(`/api/admin/licenses/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip, expires_at: expires, discord_id })
    });

    closeModal();
    refreshAll();
}

async function deleteLicense(id) {
    if (!confirm("Are you sure you want to delete this license?")) return;
    await fetchAPI(`/api/admin/licenses/${id}`, { method: 'DELETE' });
    refreshAll();
}

async function resetIP(id) {
    if (!confirm("Reset IP binding for this license?")) return;
    await fetchAPI(`/api/admin/licenses/${id}/reset-ip`, { method: 'POST' });
    refreshAll();
}

async function toggleStatus(id) {
    await fetchAPI(`/api/admin/licenses/${id}/toggle`, { method: 'POST' });
    refreshAll();
}

function refreshAll() {
    loadStats();
    loadLicenses();
    loadLogs();
}

// Initial Load
// Check for URL params (Discord Login)
const urlParams = new URLSearchParams(window.location.search);
const token = urlParams.get('token');
const username = urlParams.get('username');

if (token) {
    localStorage.setItem('admin_token', token);
    if (username) localStorage.setItem('admin_username', username);
    window.history.replaceState({}, document.title, "/dashboard.html");
}

refreshAll();

// Update UI with username
const storedUsername = localStorage.getItem('admin_username') || 'Admin';
document.getElementById('adminUsername').textContent = storedUsername;
document.getElementById('headerUsername').textContent = storedUsername;
document.getElementById('headerInitials').textContent = storedUsername.charAt(0).toUpperCase();

function showSection(section) {
    // Hide all
    document.getElementById('statsSection').classList.add('hidden');
    document.getElementById('licensesSection').classList.add('hidden');
    document.getElementById('logsSection').classList.add('hidden');
    document.getElementById('adminsSection').classList.add('hidden');

    // Show selected
    if (section === 'admins') {
        document.getElementById('adminsSection').classList.remove('hidden');
        loadAdmins();
    } else {
        document.getElementById('statsSection').classList.remove('hidden');
        document.getElementById('licensesSection').classList.remove('hidden');
        document.getElementById('logsSection').classList.remove('hidden');
    }
}

async function loadAdmins() {
    const admins = await fetchAPI('/api/admin/admins');
    const tbody = document.getElementById('adminsTable');

    if (admins.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="p-8 text-center text-slate-500">No admins found.</td></tr>`;
        return;
    }

    tbody.innerHTML = admins.map(a => `
        <tr class="hover:bg-slate-800/30 transition group">
            <td class="p-5 font-mono text-xs text-blue-300 font-medium tracking-wide">${a.discord_id}</td>
            <td class="p-5 text-sm text-slate-300">${a.username || '-'}</td>
            <td class="p-5 text-slate-500 text-xs">${moment(a.added_at).fromNow()}</td>
            <td class="p-5 text-right">
                <button onclick="deleteAdmin(${a.id})" class="p-1.5 rounded hover:bg-red-500/20 text-red-400 transition" title="Delete">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
            </td>
        </tr>
    `).join('');
    lucide.createIcons();
}

function openAddAdminModal() {
    document.getElementById('addAdminModal').classList.remove('hidden');
}

function closeAddAdminModal() {
    document.getElementById('addAdminModal').classList.add('hidden');
}

async function addAdmin() {
    const discord_id = document.getElementById('newAdminDiscordId').value;
    const username = document.getElementById('newAdminUsername').value;

    if (!discord_id) return alert('Discord ID is required');

    await fetchAPI('/api/admin/admins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ discord_id, username })
    });

    closeAddAdminModal();
    loadAdmins();
}

async function deleteAdmin(id) {
    if (!confirm("Remove this admin?")) return;
    await fetchAPI(`/api/admin/admins/${id}`, { method: 'DELETE' });
    loadAdmins();
}
